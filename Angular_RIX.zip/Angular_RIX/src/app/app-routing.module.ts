import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenuComponent } from './dataCheck/menu.component';
import { VmenuComponent } from './visibility/vmenu.component';
import { VdisplayComponent } from './visibility/vdisplay.component';
import { BmenuComponent } from './buybility/bmenu.component';
import { BdisplayComponent } from './buybility/bdisplay.component';
import { CheckDisplayComponent } from './dataCheck/check-display.component';


const routes: Routes = [
  {path:'datacheck',component:MenuComponent},
  {path:'visibility',component:VmenuComponent},
  {path:'buyability',component:BmenuComponent},
  /* {path:'vdisplay',component:VdisplayComponent},
  {path:'bdisplay',component:BdisplayComponent},
  {path:'CheckDisplay',component:CheckDisplayComponent} */
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

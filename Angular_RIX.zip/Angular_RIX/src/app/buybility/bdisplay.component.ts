import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bdisplay',
  templateUrl: './bdisplay.component.html',
  styleUrls: ['./bdisplay.component.scss']
})
export class BdisplayComponent implements OnInit {
/* item:any
market:any */
  constructor(private router:Router) { 
   /*  this.item=sessionStorage.getItem("Item")
    this.market=sessionStorage.getItem("country")
   */}

  ngOnInit(): void {
   
  }
  
}

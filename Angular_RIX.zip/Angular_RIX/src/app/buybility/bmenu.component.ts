import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bmenu',
  templateUrl: './bmenu.component.html',
  styleUrls: ['./bmenu.component.scss']
})
export class BmenuComponent implements OnInit {
bdata:any={}
flag:boolean=false
splittedData:any=[]
countries:any=['AT-AUSTRIA','AU-AUSTRALIA','BE-BELGIUM','CA-CANADA','CH-SWITZERLAND','CL-CHILE',
'CN-CHINA','CZ-CZECH REPUBLIC','DE-GERMANY',
'DK-DENMARK','ES-SPAIN','FI-FINLAND','FR-FRANCE','GB-ENGLAND',
'HR-CROATIA','HU-HUNGARY','IE-IRELAND','IN-INDIA'
,'IT-ITALIA','JP-JAPAN','KR-KOREA','NL-NETHERLANDS','NO-NORWAY',
'PL-POLAND','PT-PORTUGAL','RO-ROMANIA','RS-SERBIA','RU-RUSSIA',
'SE-SWEDEN','SI - SLOVENIA','SK--SLOVAKIA','US-USA',
'UA-UKRAINE','TW-TAIWAN','TR-TURKEY','TH-THAILAND'
,'SP-MALLORCA','SG-SINGAPORE','SA-SAUDI ARABIA','QA-QATAR',
'MY-MALAYSIA','MX-MEXICO','MA-MOROCCO','LV-LATVIA','LT-LITHUANIAN'
,'KW-KUWAIT','JO-JORDON','IS-ICE LAND','IL-ISRAEL','ID-INDONESIA'
,'HK-HONG KONG','GR-GREECE','EG-EGYPT','DO-DOMINICAN REPUBLIC','CY-CYPRUS','CE-TENERIFFA','BH-BAHRIN',
'BG-BULGARIA','AUW-AUSTRALIA WEST','AE-UNITED ARAB EMIRATES'
]
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onCheck()
  {
    
   /*  this.router.navigate(['./bdisplay']) */
   this.flag=true
   this.splittedData = this.bdata.itemNo.split(',')
  }
  
}

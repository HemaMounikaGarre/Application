import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vdisplay',
  templateUrl: './vdisplay.component.html',
  styleUrls: ['./vdisplay.component.scss']
})
export class VdisplayComponent implements OnInit {
/* Vitem:any
Vmarket:any */
  constructor() {
    /* this.Vitem=sessionStorage.getItem("VItem")
    this.Vmarket=sessionStorage.getItem("Vcountry") */
   }

  ngOnInit(): void {
    
  }

}

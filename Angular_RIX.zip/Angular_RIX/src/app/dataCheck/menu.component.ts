import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  quality:any={}
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
   /*  console.log("in data"+this.quality.source+"dest"+this.quality.dest) */
   

   /*  this.router.navigate(['./CheckDisplay'])  */
  }
}

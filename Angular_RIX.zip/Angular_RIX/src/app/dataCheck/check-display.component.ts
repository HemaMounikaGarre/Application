import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-display',
  templateUrl: './check-display.component.html',
  styleUrls: ['./check-display.component.scss']
})
export class CheckDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

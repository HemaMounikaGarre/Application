import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'market'
})
export class MarketPipe implements PipeTransform {

  transform(items: any[], searchText: string): any[] {
 return items.filter( it => {
   
     return searchText.toUpperCase().startsWith(it.charAt(0))
     /*  console.log( "in filter methd"+searchText.toUpperCase().startsWith(it.slice(0,2)))
      console.log("in fil method"+it) */
    });
   }

}

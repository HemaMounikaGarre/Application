import { MarketPipe } from './market.pipe';

describe('MarketPipe', () => {
  it('create an instance', () => {
    const pipe = new MarketPipe();
    expect(pipe).toBeTruthy();
  });
});
